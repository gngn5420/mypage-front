const Admin=()=>{
  return <div> 관리자 페이지</div>
}
export default Admin;